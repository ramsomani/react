import React, { Component } from 'react';

function foo() {}

class App extends Component {
  render() {
    return <div />;
  }
}

export default App;
