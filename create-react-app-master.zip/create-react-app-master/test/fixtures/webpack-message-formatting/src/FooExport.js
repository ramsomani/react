export function foo() {
  console.log('bar');
}
